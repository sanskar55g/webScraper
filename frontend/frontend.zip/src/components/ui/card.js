export function Card({ children }) {
    return <div className="p-5 bg-gray-800 rounded-lg shadow-md">{children}</div>;
  }
  