import { Button } from "./components/ui/button";
import { Progress } from "./components/ui/progress";
import { Card } from "./components/ui/card";


export default function WebScraper() {
  const [url, setUrl] = useState("");
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [csvLink, setCsvLink] = useState(null);

  const handleScrape = async () => {
    setLoading(true);
    setProgress(10);
    try {
      const response = await axios.post("http://localhost:5050/scrape", { url });
      setData(response.data);
      setCsvLink(null);
      setLoading(false);
    } catch (error) {
      console.error("Scraping failed", error);
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center p-10 min-h-screen bg-black text-white">
      <motion.h1 initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1 }}
        className="text-3xl font-bold text-purple-400">
        Fancy Web Scraper
      </motion.h1>

      <div className="flex space-x-4 my-5">
        <input type="text" placeholder="Enter website URL" value={url} onChange={(e) => setUrl(e.target.value)}
          className="w-96 p-2 border rounded-lg bg-gray-800 text-white" />
        <button onClick={handleScrape} className="bg-purple-500 hover:bg-purple-700 p-2 rounded-lg">
          Scrape
        </button>
      </div>

      {loading && <div className="w-full h-2 bg-gray-600 rounded-lg overflow-hidden mt-3">
        <div className="h-full bg-green-400 transition-all" style={{ width: `${progress}%` }}></div>
      </div>}

      {data.length > 0 && (
        <div className="mt-5 w-full max-w-2xl p-5 bg-gray-800 rounded-lg shadow-md">
          <h2 className="text-xl font-bold">Scraped Data</h2>
          <ul className="mt-2 text-sm">
            {data.map((item, index) => (
              <li key={index} className="border-b py-1">{item}</li>
            ))}
          </ul>
          {csvLink && <a href={csvLink} download className="block mt-2 text-blue-400">Download CSV</a>}
        </div>
      )}
    </div>
  );
}
